#### 个人简历模板

> 做一个属于自己的个人博客模板

### 第一步 下载模板

> 方式一git下载：git clone git@github.com:bear01/Resume.git
>
> 方式二zip下载：https://github.com/bear01/Resume

### 第二步 下载Typora

> [官网链接](https://www.typora.io/)

### 第三步 导入主题

> 安装Typora后，打开软件，点击文件-->偏好设置-->外观-->打开主题-->找到下载的模板中resume.css-->保存

### 第四步 导入模板

> 打开模板中Resume.md， 在主题中选择Resume主题即可制作属于自己的模板。
>
> md文档默认排版空隙很大，该主题可以让内容更加紧凑，让简历内容尽量控制在一到两页。

### 第五步 编辑内容

> 模板内容、图标可自行进行调整和修改

### 第六步 导出简历

> 我们不可能把md格式的简历给面试官，所以需要转换成pdf格式，具体步骤：
>
> 文件-->导出-->选择pdf

一个属于自己的简历模板就做好啦~~~



![](C:\Users\win10\Desktop\工作\简历\assets\Resume.png)